function seenBroadcast(){
    window.location.href = "profile.php#broadwidget";
    //window.setTimeout(function(){
    //    $.get("phpfunc/seenbroadcast.php");
    //}, 5000);
}

function seenComment(){
    window.location.href = "profile.php#commentwidget";
}
