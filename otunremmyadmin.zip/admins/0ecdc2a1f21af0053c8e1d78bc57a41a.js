!function(){$(function(){})}.call(this);
;