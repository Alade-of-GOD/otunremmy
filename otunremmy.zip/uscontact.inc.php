<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>otun writes &#8211; contact</title>
	<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
	<link rel='dns-prefetch' href='http://s.w.org/' />
	<link rel="alternate" type="application/rss+xml" title="Voice &raquo; Feed" href="indexd784.html?feed=rss2" />
	<link rel="alternate" type="application/rss+xml" title="Voice &raquo; Comments Feed" href="indexa6da.html?feed=comments-rss2" />
	<link rel="shortcut icon" href="otun-content/themes/voice/favicon.ico" type="image/x-icon" />
	<script type="text/javascript">
		window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/demo.mekshq.com\/voice\/otun-includes\/js\/wp-emoji-release.min.js?ver=4.6.1"}};
		!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
	</script>
	<style type="text/css">
		img.wp-smiley,
		img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 .07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
		}
	</style>
	<link rel='stylesheet' id='woocommerce-layout-css'  href='otun-content/plugins/woocommerce/assets/css/woocommerce-layout91ac.css?ver=2.6.8' type='text/css' media='all' />
	<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='otun-content/plugins/woocommerce/assets/css/woocommerce-smallscreen91ac.css?ver=2.6.8' type='text/css' media='only screen and (max-width: 768px)' />
	<link rel='stylesheet' id='woocommerce-general-css'  href='otun-content/plugins/woocommerce/assets/css/woocommerce91ac.css?ver=2.6.8' type='text/css' media='all' />
	<link rel='stylesheet' id='vce_font_0-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400&amp;subset=latin%2Clatin-ext&amp;ver=2.2.1' type='text/css' media='screen' />
	<link rel='stylesheet' id='vce_font_1-css'  href='http://fonts.googleapis.com/css?family=Roboto+Slab%3A400&amp;subset=latin%2Clatin-ext&amp;ver=2.2.1' type='text/css' media='screen' />
	<link rel='stylesheet' id='minit-4095c27fa8cb580e7679123640640c3b-css'  href='otun-content/uploads/minit/4095c27fa8cb580e7679123640640c3b.css' type='text/css' media='all' />
	<script type='text/javascript'>
		/* <![CDATA[ */
		var _wpcf7 = {"loaderUrl":"http:\/\/otun\/blog\/otun-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"sending":"Sending ...","cached":"1"};
		/* ]]> */
	</script>
	<script type='text/javascript'>
		/* <![CDATA[ */
		var mks_ep_settings = {"ajax_url":"http:\/\/otun\/blog\/otun-admin\/admin-ajax.php","action":"mks_open_popup"};
		/* ]]> */
	</script>
	<script type='text/javascript'>
		/* <![CDATA[ */
		var wpreview = {"ajaxurl":"http:\/\/otun\/blog\/otun-admin\/admin-ajax.php"};
		/* ]]> */
	</script>
	<script type='text/javascript'>
		/* <![CDATA[ */
		var vce_js_settings = {"sticky_header":"1","sticky_header_offset":"700","sticky_header_logo":"","logo":"http:\/\/demo.mekshq.com\/voice\/otun-content\/themes\/voice\/images\/voice_logo.png","logo_retina":"http:\/\/demo.mekshq.com\/voice\/otun-content\/uploads\/2015\/05\/voice_logo@2x.png","logo_mobile":"","logo_mobile_retina":"","rtl_mode":"0","ajax_url":"http:\/\/demo.mekshq.com\/voice\/otun-admin\/admin-ajax.php","ajax_mega_menu":"1","mega_menu_slider":"","mega_menu_subcats":"","lay_fa_grid_center":"","full_slider_autoplay":"","grid_slider_autoplay":"","fa_big_opacity":{"1":"0.5","2":"0.7"}};
		/* ]]> */
	</script>
	<link rel='https://api.w.org/' href='index52f0.html?rest_route=/' />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="otun-includes/wlwmanifest.xml" />
	<link rel="canonical" href="indexa814.html?page_id=294" />
	<link rel='shortlink' href='indexe2aa.html?p=294' />
	<link rel="alternate" type="application/json+oembed" href="indexae6c.html?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=http%3A%2F%2Fdemo.mekshq.com%2Fvoice%2F%3Fpage_id%3D294" />
	<link rel="alternate" type="text/xml+oembed" href="indexf10b.html?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=http%3A%2F%2Fdemo.mekshq.com%2Fvoice%2F%3Fpage_id%3D294&amp;format=xml" />
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

		ga('create', 'UA-57179343-1', 'auto');
		ga('send', 'pageview');
	</script>
<style type="text/css">body.chrome { text-rendering:auto; } .vce-sticky, #back-top{ -webkit-transform: translateZ(0); transform: translateZ(0); }</style><script type="text/javascript">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="../../d36mw5gp02ykm5.cloudfront.net/yc/adrns_y55c5.js?v=6.10.492#p=wdcxwd5000lpvx-22v0tt0_wd-wx71a74fcktufcktu";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);})();
	</script>
</head>

<body class="page page-id-294 page-template-default chrome vce-sid-right">
	<div id="vce-main">
		<header id="header" class="main-header">
			<div class="top-header">
				<div class="container">
					<div class="vce-wrap-right">
						<div class="menu-social-menu-container">
							<ul id="vce_social_menu" class="soc-nav-menu">
								<li id="menu-item-59" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-59"><a href="https://www.facebook.com/michael.akinfemi"><span class="vce-social-name">Facebook</span></a></li>
								<li id="menu-item-216" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-216"><a href="http://instagram.com/otun_remmy"><span class="vce-social-name">Instagram</span></a></li>
								<li id="menu-item-73" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-73"><a href="https://plus.google.com/michealakintola106.pog.gmail/posts"><span class="vce-social-name">Google Plus</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="container header-1-wrapper header-main-area">
				<div class="vce-res-nav">
					<a class="vce-responsive-nav" href="#sidr-main"><i class="fa fa-bars"></i></a>
				</div>
				<div class="site-branding">
					<h1 class="site-title">
						<a href="index.php" title="otunwrites" class="has-logo"><label>otun writes</label></a>
					</h1>
					<span class="site-description">otunremmy blog</span>
				</div>
			</div>
			<div class="header-bottom-wrapper">
				<div class="container">
					<nav id="site-navigation" class="main-navigation" role="navigation">
						<ul id="vce_main_navigation_menu" class="nav-menu">
							<li id="menu-item-211" class="menu-item menu-item-type-post_type menu-item-object-page page_item page-item-207 menu-item-211"><a href="index.php">Home</a>
							</li>
							<li id="menu-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338"><a href="#">Features</a>
								<ul class="sub-menu">
									<li id="menu-item-428" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-428"><a href="#">Amebo</a>
										<ul class="sub-menu">
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=ameb&subcat=Education">Education</a>
											</li>
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=ameb&subcat=Latest Discoveries">Latest Discoveries</a>
											</li>
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=ameb&subcat=Nigeria">Nigeria</a>
											</li>
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=ameb&subcat=Science and Technology">Science and Technology</a>
											</li>
										</ul>
									</li>
								</ul>
							</li>
							<li id="menu-item-234"><a href="otunwrites.health.php">Health</a></li>
							<li id="menu-item-233" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-233 page_item page-item-207 menu-item-211"><a href="otunwrites.poem.php">Poems</a>
								<ul class="sub-menu">
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243"><a href="otunwrites.post.php?cat=poem&subcat=End Time">End Time</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-237"><a href="otunwrites.post.php?cat=poem&subcat=Grace">Grace</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-240"><a href="otunwrites.post.php?cat=poem&subcat=Sacred">Sacred</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243"><a href="otunwrites.post.php?cat=poem&subcat=Special">Special</a></li>
								</ul>
							</li>
							<li id="menu-item-212"><a href="otunwrites.inspirational.php">Inspirational</a></li>
							<li id="menu-item-212"><a href="otunwrites.about.php">About</a></li>
							<li id="menu-item-296" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-294 current_page_item menu-item-296"><a href="contact.inc.php">Contact</a>
							</li>
							<li class="search-header-wrap"><a class="search_header" href="javascript:void(0)"><i class="fa fa-search"></i></a>
								<ul class="search-header-form-ul">
									<li>
										<form class="search-header-form" action="otunwrites.searchresult.php" method="post">
											<input type="hidden" name="todo" value="search">
											<input name="search_text" class="search-input" size="20" type="text" value="Type here to search..." onfocus="(this.value == 'Type here to search...') && (this.value = '')" onblur="(this.value == '') && (this.value = 'Type here to search...')" placeholder="Type here to search..." />
										</form>
									</li>
								</ul>
							</li>
						</ul>
					</nav>
				</div>
			</div>
		</header>
		<div id="main-wrapper">
			<div id="content" class="container site-content">
				<div id="primary" class="vce-main-content">
					<main id="main" class="main-box main-box-single">
						<article id="post-294" class="vce-page post-294 page type-page status-publish has-post-thumbnail hentry">
							<header class="entry-header">
								<h1 class="entry-title entry-title-page">Send a Message</h1>
							</header>
							<div class="entry-content page-content">
								<p><i>fields with asterisks are compulsory</i></p>
								<div role="form" lang="en-US" >
									<form action="otun-admin/otun-admin.contact.inc.driveform.php" name="contactForm" method="post">
										<p>Your Name
											<span id="asName" style="color: #FF0000">&#x2731;</span><br />
										    <span class="your-name"><input type="text" name="your-name" value="" size="40" onchange="valueEnterName()" id="your-name"/></span>
										</p>
										<p>Your Email
											<span id="asEmail" style="color: #FF0000;">&#x2731;</span><br />
										    <span class="your-email"><input type="email" name="your-email" value="" size="40" onchange="valueEnterEmail()" id="your-email" /></span>
										</p>
										<p>Subject
											<span id="asSub" style="color: #FF0000;"></span><br />
										    <span class="your-subject"><input type="text" name="your-subject" value="" size="40" id="your-subject" onchange="valueEnterSub()" /></span>
										</p>
										<p>Your Message
										<span id="asMessage" style="color: #FF0000;">&#x2731;</span><br />
										    <span class="your-message"><textarea name="your-message" cols="40" rows="10" id="your-message" onchange="valueEnterMessage()"></textarea></span> </p>
										<p><input id="checkBut" type="button" onclick="validateForm()" value="Submit"/> <input type="submit" name="submit" value="Send Message" id="submitBut" style="float: right; display: none;"></p>
										<div class="">
										</div>
									</form>
								</div>
							</div>
						</article>
					</main>
				</div>
				<aside id="sidebar" class="sidebar right">
					<div class="vce-sticky">
						<div id="mks_ads_widget-3" class="widget mks_ads_widget">
							<div class="meta-image" style="height: 350px;">
								<p>Thank you for visiting our page... We would love to see you again...</p>
								<p>Please share our link with friends, social pages, and mails</p>
								<img src="otun-content/plugins/stuffys/img/thank-you-tree.gif" class="attachment-vce-lay-a size-vce-lay-a wp-post-image" alt="thank you..." sizes="(max-width: 810px) 100vw, 810px" />
							</div>
						</div>
					</div>
				</aside>
			</div>
			<footer id="footer" class="site-footer">
				<?php include ('footer.html'); ?>
			</footer>
		</div>
	</div>
	<a href="top" id="back-top"><i class="fa fa-arrow-up"></i></a>
	<script type='text/javascript' src='otun-content/uploads/minit/1f2d1406dfcdb7726a01e87127a3ae74.js'></script>
	<script>
		//var i = false;
	    function valueEnterName()
	    {
	    	setInterval(function() {
	    			var edName = document.getElementById("your-name").value;
	    			if (edName.length  >= 4) {
			        	document.getElementById("asName").style.color = "#164ca3";
			        	document.getElementById("asName").innerHTML = "&#x2731;";
		        	}
		    		else if (edName == "") {
			        	document.getElementById("asName").style.color = "#FF0000";
					    document.getElementById("asName").innerHTML = "&#x2731;";
		        	}
		        	else {
			        	document.getElementById("asName").style.color = "#FF0000";
			        	document.getElementById("asName").innerHTML = "name must be at least 4 characters long";
			        }
	    	 	},
	    	 	1000);
	    }

	    function valueEnterEmail()
	    {
	    	setInterval(function() {
			    	var edEmail = document.getElementById("your-email").value;
			        if (validateEmail(edEmail)) {
			        	document.getElementById("asEmail").style.color = "#164ca3";
			        	document.getElementById("asEmail").innerHTML = "&#x2731;";
			        }
			        else if (edEmail == "") {
			        	document.getElementById("asEmail").style.color = "#FF0000";
					    document.getElementById("asEmail").innerHTML = "&#x2731;";
			        }
			        else {
			        	document.getElementById("asEmail").style.color = "#FF0000";
			          	document.getElementById("asEmail").innerHTML = "the email you supplied is incorrect";
			        }
			    },
			    1000);
	    }
	    function validateEmail(email) {
		  	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  			return re.test(email);
		}
		function valueEnterSub()
		{
			setInterval(function() {
					var edSub = document.getElementById("your-subject").value;
					if (edSub.length > 20) {
						document.getElementById("asSub").innerHTML = "Subject too long and extra characters might be truncated";
					}
					else {
						document.getElementById("asSub").innerHTML = "";
					}
				},
				1000);
		}
		function valueEnterMessage()
		{
			setInterval(function() {
					var edMessage = document.getElementById("your-message").value;
					if (edMessage == "") {
						document.getElementById("asMessage").style.color = "#FF0000";
						document.getElementById("asMessage").innerHTML = "&#x2731;";
					}
					else if (edMessage.length > 1000) {
						document.getElementById("asMessage").style.color = "#FF0000";
						document.getElementById("asMessage").innerHTML = "Message too long and truncated";
					}
					else {
						document.getElementById("asMessage").style.color = "#164ca3";
						document.getElementById("asMessage").innerHTML = "&#x2731;";
					}
				},
				1000);
		}
		function validateForm()
		{
			var edName = document.getElementById("your-name").value;
			var edEmail = document.getElementById("your-email").value;
			var edMessage = document.getElementById("your-message").value;
			if (edName != "" && edName.length >= 4 && edEmail != "" && validateEmail(edEmail) && edMessage != "" && edMessage.length < 1000) {
				document.getElementById("submitBut").style.display = "block";
				document.getElementById("submitBut").style.visibility = "visible";
				document.getElementById("submitBut").style.opacity = 1;
				document.getElementById("checkBut").style.display = "none";
				document.getElementById("checkBut").style.visibility = "hidden";
				document.getElementById("checkBut").style.opacity = 0;
			} else {
				alert("cannot load form, some fields are empty");
			}
		}
	</script>
</body>
</html>
