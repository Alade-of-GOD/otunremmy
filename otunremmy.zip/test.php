<?php

    $r = '26/01/2017';

    echo date("d/m/Y");

?>
