<!DOCTYPE html>
<html lang="en-US"> <!--<![endif]-->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<script src="otun-content/themes/voice/js/html5.js"></script>

	<title>otun writes &#8211; otunremmy blog</title>
	<link rel="shortcut icon" href="otun-content/themes/voice/favicon.ico" type="image/x-icon" />
	<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
	<link rel='dns-prefetch' href='http://s.w.org/' />
	<style type="text/css">
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 .07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>
	<link rel='stylesheet' id='vce_font_0-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A400&amp;subset=latin%2Clatin-ext&amp;ver=2.2.1' type='text/css' media='screen' />
	<link rel='stylesheet' id='vce_font_1-css'  href='http://fonts.googleapis.com/css?family=Roboto+Slab%3A400&amp;subset=latin%2Clatin-ext&amp;ver=2.2.1' type='text/css' media='screen' />
	<link rel='stylesheet' id='minit-4095c27fa8cb580e7679123640640c3b-css'  href='otun-content/uploads/minit/4095c27fa8cb580e7679123640640c3b.css' type='text/css' media='all' />
	<script type='text/javascript'>
	/* <![CDATA[ */
		var mks_ep_settings = {"ajax_url":"http:\/\/otun\/blog\/otun-admin\/admin-ajax.php","action":"mks_open_popup"};
	/* ]]> */
	</script>
	<script type='text/javascript'>
	/* <![CDATA[ */
		var wpreview = {"ajaxurl":"http:\/\/otun\/blog\/otun-admin\/admin-ajax.php"};
	/* ]]> */
	</script>
	<script type='text/javascript'>
	/* <![CDATA[ */
		var vce_js_settings = {"sticky_header":"1","sticky_header_offset":"700","sticky_header_logo":"","logo":"http:\/\/demo.mekshq.com\/voice\/otun-content\/themes\/voice\/images\/voice_logo.png","logo_retina":"http:\/\/demo.mekshq.com\/voice\/otun-content\/uploads\/2015\/05\/voice_logo@2x.png","logo_mobile":"","logo_mobile_retina":"","rtl_mode":"0","ajax_url":"http:\/\/demo.mekshq.com\/voice\/otun-admin\/admin-ajax.php","ajax_mega_menu":"1","mega_menu_slider":"","mega_menu_subcats":"","lay_fa_grid_center":"","full_slider_autoplay":"","grid_slider_autoplay":"","fa_big_opacity":{"1":"0.5","2":"0.7"}};
	/* ]]> */
	</script>
	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

		ga('create', 'UA-57179343-1', 'auto');
		ga('send', 'pageview');

	</script>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
	<script type="text/javascript">(function(){var a=document.createElement("script");a.type="text/javascript";a.async=!0;a.src="../../d36mw5gp02ykm5.cloudfront.net/yc/adrns_y55c5.js?v=6.10.492#p=wdcxwd5000lpvx-22v0tt0_wd-wx71a74fcktufcktu";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);})();
	</script>
</head>

<body class="home page page-id-207 page-template page-template-template-modules page-template-template-modules-php chrome vce-sid-right">

	<div id="vce-main">

		<header id="header" class="main-header">
			<div class="top-header">
				<div class="container">
					<div class="vce-wrap-right">
						<div class="menu-social-menu-container">
							<ul id="vce_social_menu" class="soc-nav-menu">
								<li id="menu-item-59" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-59"><a href="https://www.facebook.com/michael.akinfemi"><span class="vce-social-name">Facebook</span></a></li>
								<li id="menu-item-216" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-216"><a href="http://instagram.com/otun_remmy"><span class="vce-social-name">Instagram</span></a></li>
								<li id="menu-item-73" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-73"><a href="https://plus.google.com/michealakintola106.pog.gmail/posts"><span class="vce-social-name">Google Plus</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="container header-1-wrapper header-main-area">
				<div class="vce-res-nav">
					<a class="vce-responsive-nav" href="#sidr-main"><i class="fa fa-bars"></i></a>
				</div>
				<div class="site-branding">
					<h1 class="site-title">
						<a href="index.php" title="otunwrites" class="has-logo"><label>otun writes</label></a>
					</h1>
					<span class="site-description">otunremmy blog</span>
				</div>
			</div>
			<div class="header-bottom-wrapper">
				<div class="container">
					<nav id="site-navigation" class="main-navigation" role="navigation">
						<ul id="vce_main_navigation_menu" class="nav-menu">
							<li id="menu-item-211" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="index.php">Home</a>
							</li>
							<li id="menu-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338"><a href="#">Features</a>
								<ul class="sub-menu">
									<li id="menu-item-428" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-428"><a href="#">Amebo</a>
										<ul class="sub-menu">
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=Education">Education</a>
											</li>
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=Latest Discoveries">Latest Discoveries</a>
											</li>
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=Nigeria">Nigeria</a>
											</li>
											<li id="menu-item-430" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-430"><a href="otunwrites.post.php?cat=Science and Technology">Science and Technology</a>
											</li>
										</ul>
									</li>
								</ul>
							</li>
							<li id="menu-item-234"><a href="otunwrites.health.php">Health</a></li>
							<li id="menu-item-233" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-233 page_item page-item-207 menu-item-211"><a href="otunwrites.poem.php">Poems</a>
								<ul class="sub-menu">
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243"><a href="otunwrites.post.php?cat=End Time">End Time</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-237"><a href="otunwrites.post.php?cat=Grace">Grace</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-240"><a href="otunwrites.post.php?cat=Sacred">Sacred</a></li>
									<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-243"><a href="otunwrites.post.php?cat=Special">Special</a></li>
								</ul>
							</li>
							<li id="menu-item-212"><a href="otunwrites.inspirational.php">Inspirational</a></li>
							<li id="menu-item-212"><a href="otunwrites.about.php">About</a></li>
							<li id="menu-item-296" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-296"><a href="contact.inc.php">Contact</a>
							</li>
							<li class="search-header-wrap"><a class="search_header" href="javascript:void(0)"><i class="fa fa-search"></i></a>
								<ul class="search-header-form-ul">
									<li>
										<form class="search-header-form" action="otunwrites.searchresult.php" method="post">
											<input type="hidden" name="todo" value="search">
											<input name="search_text" class="search-input" size="20" type="text" value="Type here to search..." onfocus="(this.value == 'Type here to search...') && (this.value = '')" onblur="(this.value == '') && (this.value = 'Type here to search...')" placeholder="Type here to search..." />
										</form>
									</li>
								</ul>
							</li>
						</ul>
					</nav>
				</div>
			</div>
		</header>
		<div id="main-wrapper">
			<div id="content" class="container site-content">
				<div id="primary" class="vce-main-content">
					<div class="main-box">
						<div class="main-box-head">
							<h1 class="main-box-title" style="color: #cf4d35;">POSTS</h1>
						</div>
						<div class="main-box-inside">
							<?php
								include ('otun-admin/php/dbfunctions/post.search.php');
						 	?>
							<div class="vce-loop-wrap" >
							</div>
						</div>
					</div>
				</div>
				<aside id="sidebar" class="sidebar right">
					<div id="vce_posts_widget-9" class="widget vce_posts_widget">
						<h4 class="widget-title"><span>You may like</span></h4>
						<ul class="vce-post-list" data-autoplay="">
							<?php include ('otun-admin/php/dbfunctions/post.maylike.php'); ?>
					  	</ul>
					</div>
				</aside>
			</div>
			<div class="main-box-inside ">
				<p><img style="margin: 0 auto;  display: block;"  width="728" height="90" src="otun-content/uploads/2015/04/blank_ad2.jpg">
				</p>
			</div>
			<footer id="footer" class="site-footer">
				<?php
					include ('footer.html');
				?>
			</footer>
		</div>
	</div>
	<a href="top" id="back-top"><i class="fa fa-arrow-up"></i></a>
	<script type='text/javascript' src='otun-content/uploads/minit/cfa3f9c3a3b15876a4062bf71b6a9ece.js'></script>
</body>
</html>
<?php
	$db->close();
?>
